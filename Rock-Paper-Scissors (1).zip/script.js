
/*
 * ASSIGNMENT 4
 * Title: Rock, Paper, Scissors
 * Variables: 
 * SUMMARY 
 * Important program elements used:
 1. Variables
 2. Functions
 3. Arrays
 4. If/if else statements
 5. Console.log 
 6. .toLowerCase
 7 Switch
 8. document.getElementById
 9.
 10.




 
 variables, Math.floor,   
 * .random, newDate (), 7 points UI/UX, switch(), 
 
 * prompt(), alert()
 * April, 2023
 * Partners: Will Jo, Ryan Liu, Simone, Ryan R.
 */




/*
summary: 
@parms: 
@return: 
*/



//Beginning of Program 



//Variable declaration
const date = new Date()
const todaysDate = date.toLocaleDateString()
var userName = prompt('Insert your name')




//Beginning of User interface 7 part UI-UX Function
function userInterface () {
  console.log('Rock Paper Scissors'); //Title pf program
  console.log(`Hi ${userName}. Welcome to Rock Paper Scissors`); //Welcome statement
  console.log(todaysDate)// Date
  console.log('Choose either rock, paper or scissors'); //Introduction
  console.log('The computer will randomly generate rock, paper, and scissors'); //Explanation
  console.log('The round can result in a win, a loss, or a tie'); //Explanation 
  console.log('Thank you for visiting our website. Tune in everytime you need and want to play Rock, Paper, Scissors'); //Thank you statement

} //End of userInterface function




userInterface();
//Beginning of getUserChoice function
function getUserChoice() {
  var userInput = prompt("Enter Rock, Paper or Scissors"); // Prompt that allows user to enter in rock paper or scussors
  if (userInput) {
    userInput = userInput.toLowerCase(); //converts user input to lower case 
    }


  
  switch (userInput) {
  case 'rock':
  case 'r':
  case 'rok':
  case 'roc':
   return "rock";
    break; // Switch that allows user to mae mistakes and still get the output rock
  case 'paper':
  case 'p':
  case 'pa':
  case 'pap':
    case 'pape':
    return "paper";
    break; // Switch that allows user to mae mistakes and still get the output paper
  case 'scissors':
  case 's':
  case 'scisors':
  case 'cisors':
  case 'sci':
    return "scissors";
    break; // Switch that allows user to mae mistakes and still get the output scissors
  }
return userInput;


} //End of getUserChoice function
    




//Beginning of getComputerChoice function 
function getComputerChoice () {
 var answers = [];

  
  answers[0] = "ROCK"; // 0 is rock
  answers[1] = "PAPER"; // 1 is paper
  answers[2] = "SCISSORS"; // 2 is scissors

  var i = Math.floor((Math.random() * 2.9999)); //generate random number between 0 and 2.999
  console.log(i);
  console.log(answers[i]);
  
  return answers[i].toLowerCase(); // answers are returned to lowercase
  
} //End of getComputerChoice function 





function determineWinner(userChoice, computerChoice) {
  if (userChoice === computerChoice) {
    console.log('The round ended in a tie.')
    return "tie"; // Determines winner based on userchoice and computer choice
  } 
  
  if (userChoice === "rock") {
    if (computerChoice === "paper") {
      console.log('You Lose!!!');
      return "computer"; // returns computer when user loses
      
    } else if (computerChoice === "scissors") {
      console.log('You Win!!!'); 
      return "user"; // returns user when user wins!
    }
  }

  else if (userChoice === "paper") {
    if (computerChoice === "scissors") {
      console.log('You Lose!!!');
      return "computer"; // paper loses to scissors therefore computer wins
      
    } else if (computerChoice === "rock") {
      console.log('You Win!!!'); 
      return "user"; // user wins if you beat computer
    }
  }

  else if (userChoice === "scissors") {
    if ((computerChoice === "rock")) {
      console.log('You Lose!!!');
      return "computer"; //scissors loses to rock, computer wins
      
    } else if (computerChoice === "paper") {
      console.log('You Win!!!'); 
      return "user"; // scissors beats paper  
    }
  }
  else {
    console.log('Error !! Play again'); // console log play agin if there is an error
  }
  return "Error, please check your input!"; // if input is not one of the possible inputs, the message error please check your input is displayed

}




function determineWinnerTwo(playerOneChoice, playerTwoChoice) {


  if (playerOneChoice === playerTwoChoice) {
    console.log('The round ended in a tie.') //it ties if user's choice and computer's output match
    return "tie";
  } 

  if (playerOneChoice === "rock") {
    if (playerTwoChoice === "paper") {
      console.log('You Win!!!');
      return "player 2"; // player 2 wins as paper beats rock
      
    } else if (playerTwoChoice === "scissors") {
      console.log('You Win!!!'); 
      return "player 1"; // player one wins as scissors loses to rock
    }
  }

  else if (playerOneChoice === "paper") {
    if (playerTwoChoice === "scissors") {
      console.log('You Win!!!');
      return "player 2"; // player 2 wins as scissors beats paper
      
    } else if (playerTwoChoice === "rock") {
      console.log('You Win!!!'); 
      return "player 1"; // player 1 wins as rock beats paper
    }
  }

  else if (playerOneChoice === "rock") {
    if (playerTwoChoice === "scissors") {
      console.log('You Win!!!');
      return "player 1"; // player 1 wins as rock beats scissors
      
    } else if (playerTwoChoice === "paper") {
      console.log('You Win!!!'); 
      return "player 2"; // player 2 wins as paper beats rock
    }
  }

     
  if (playerOneChoice === "rock") {
    if (playerTwoChoice === "paper") {
      console.log('You Win!!!');
      return "player 2"; // player 2 wins as paper beats rock
      
    } else if (playerTwoChoice === "scissors") {
      console.log('You Win!!!'); 
      return "player 1"; // player 1 wins as rock beats scissors
    }
  }

  else if (playerOneChoice === "scissors") {
    if (playerTwoChoice === "paper") {
      console.log('You Win!!!');
      return "player 1"; // player 1 wins as scissors beats paper
      
    } else if (playerTwoChoice === "rock") {
      console.log('You Win!!!'); 
      return "player 2"; // player 2 wins as rock beats scissors
    }
  }

  else if (playerOneChoice === "rock") {
    if (playerTwoChoice === "scissors") {
      console.log('You Win!!!');
      return "player 1"; // player 1 wins as rock beats scissors
      
    } else if (playerTwoChoice === "paper") {
      console.log('You Win!!!'); 
      return "player 2"; // player 2 wins as paper beats rock
    } 
  else {
    console.log('Error !! Play again'); // error please check input and play again
  }
 }  
}




//start of Playgame function 
function playGame() {
  var userChoice = getUserChoice(); // User choice variable and gets user choice
  var computerChoice = getComputerChoice(); // Computer Choice and gets computer choice
  

  var winner = determineWinner(userChoice, computerChoice); // variable winner that determines winner based on user choice and computer choice
  
  document.getElementById("input").innerHTML = userChoice; // Connecting JS and HTML togehther so that the user input and computer choice are displayed onto the screen 
  document.getElementById("output").innerHTML = computerChoice;
  document.getElementById("winner").innerHTML = winner;
  
} //End of playGame function



function playAgainstFriend() {
  var playerOneChoice = prompt("Player 1: Enter Rock, Paper or Scissors"); // Prompt for player one to enter choice of weapon
  var playerTwoChoice = prompt("Player 2: Enter Rock, Paper or Scissors"); // Player 2 enters their input

  var winnerTwo = determineWinnerTwo(playerOneChoice.toLowerCase(), playerTwoChoice.toLowerCase()); // Determines winner based off the 2 players choices. Can either be win, lose, or a tie

  document.getElementById("playerOneChoice").innerHTML = playerOneChoice; // Player 1 choice dispoays on screen
  document.getElementById("playerTwoChoice").innerHTML = playerTwoChoice;
  document.getElementById("winnerTwo").innerHTML = winnerTwo;
}






//play again button
function playAgain(counter){
	if (counter === 0){
	   playGame();
  }
} // end of play again button



//play two player again button
function playTwoAgain(counter){
	if (counter === 1){
	   playAgainstFriend();
  }
} // end of two player again button

playGame(); // end of play game function


// make a scoreboard 
// add some gui button 
  

  
/*
 * End of Program
 * Notes:
 * we could add date and genral ui text, and while(), and prompts
 * function randonNumberGen ()



 Ryan Liu's Contribution
 - Connected the code between JS and HTML (document.getElementById("input").innerHTML)
 - Worked on the HTML (background colour)
 - Added comments 
 - 7 part U1-UX
 - Added all the console.log(''); statements to help the user to navigate our game
 - Worked on Switch statement by adding cases for most probable inputs by the user
 - Added whitespace to organize code better
 - Added elements used in the Important program elements used: section
 

Ryan Roumiani's Contribution
-Made the Determine winner function for two player
-Made two player rock paper scissors
-Did the document.get element for two player function
-Photoshopped the logo 
-Added Title Font
-Made buttons for play again against the computer 
-Made buttons for two player
-Fixed any bugs or errors in other codes
-Made the cheat code function for two player
-Worked on HTML and CSS

 Simone's Contribution
-  Addition of the date in cosole
-  Username input
-  Switch
-  Helped with UI/UX and commenting

Will's Contribution 
- determineWinner function  
- Change Background colour 
- Play game function <- except the document HTML .. 
- Fixed lots of messy codes/errors && --> if statement e.g determineWinner fucntion 
- getComputerChoice function
- Add how to play table HTML

 */



